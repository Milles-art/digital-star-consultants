<?php $__env->startSection('content'); ?>
<?php
    $categoryIcon = function ($category) {
        $slug = strtolower($category->slug ?? '');
        return match (true) {
            str_contains($slug, 'government') => 'government',
            str_contains($slug, 'passport') || str_contains($slug, 'immigration') => 'passport',
            str_contains($slug, 'jobs') => 'jobs',
            str_contains($slug, 'education') => 'education',
            str_contains($slug, 'tra') || str_contains($slug, 'tax') => 'tax',
            str_contains($slug, 'travel') => 'travel',
            str_contains($slug, 'printing') => 'printing',
            str_contains($slug, 'stationery') => 'stationery',
            str_contains($slug, 'business') || str_contains($slug, 'brela') => 'business',
            str_contains($slug, 'it') || str_contains($slug, 'tech') => 'it',
            default => 'default',
        };
    };
?>
<section class="catalog-hero">
    <div class="catalog-hero-inner">
        <div>
            <div class="eyebrow">DIGITAL STAR SERVICES</div>
            <?php if($selectedCategory): ?>
                <div class="catalog-breadcrumb">
                    <a href="<?php echo e(route('public.services.index')); ?>">Services</a><span>›</span>
                    <?php if($selectedCategory->parent): ?>
                        <a href="<?php echo e(route('public.services.index', ['category' => $selectedCategory->parent->slug])); ?>"><?php echo e($selectedCategory->parent->name); ?></a><span>›</span>
                    <?php endif; ?>
                    <strong><?php echo e($selectedCategory->name); ?></strong>
                </div>
                <h1><?php echo e($selectedCategory->name); ?></h1>
                <p><?php echo e($selectedCategory->description ?: 'Choose the service that matches what you need.'); ?></p>
            <?php elseif($search): ?>
                <h1>Search results</h1>
                <p>Showing services that match <strong>“<?php echo e($search); ?>”</strong>.</p>
            <?php else: ?>
                <h1>Everything you need.<br><em>In one place.</em></h1>
                <p>Explore our complete service catalogue. Start with a service area, open a group, then choose the exact service you need.</p>
            <?php endif; ?>
        </div>
        <div class="catalog-stat">
            <?php if(!$selectedCategory && !$search): ?>
                <span><?php echo e($categories->sum(fn($c) => $c->children->sum('active_services_count') + $c->active_services_count)); ?></span>
                <small>services available</small>
            <?php else: ?>
                <span><?php echo e($search ? $services->count() : $services->count()); ?></span>
                <small><?php echo e($search ? 'matching services' : 'services'); ?></small>
            <?php endif; ?>
        </div>
    </div>
</section>

<section class="catalog-shell">
    <form class="catalog-search" method="GET" action="<?php echo e(route('public.services.index')); ?>">
        <span class="search-icon" aria-hidden="true">⌕</span>
        <input name="search" value="<?php echo e($search); ?>" placeholder="Search services — passport, TIN, business registration, website…" aria-label="Search services">
        <button class="button button-yellow" type="submit">Search</button>
    </form>

    <div class="catalog-tabs" aria-label="Service areas">
        <a class="catalog-tab <?php echo e(!$selectedCategory && !$search ? 'active' : ''); ?>" href="<?php echo e(route('public.services.index')); ?>">All services</a>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a class="catalog-tab <?php echo e($selectedCategory?->slug === $category->slug ? 'active' : ''); ?>" href="<?php echo e(route('public.services.index', ['category' => $category->slug])); ?>">
                <span><?php echo $__env->make('partials.icon', ['iconKey' => $categoryIcon($category)], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></span><?php echo e($category->name); ?>

            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <?php if($search): ?>
        <?php $__empty_1 = true; $__currentLoopData = $serviceGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="catalog-section">
                <div class="catalog-section-head"><div><span class="section-index"><?php echo e(str_pad($loop->iteration,2,'0',STR_PAD_LEFT)); ?></span><h2><?php echo e($group['name']); ?></h2><p><?php echo e($group['description']); ?></p></div><span class="section-count"><?php echo e($group['services']->count()); ?> services</span></div>
                <div class="service-grid service-grid-premium">
                    <?php $__currentLoopData = $group['services']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('services.partials.card', ['service' => $service], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="catalog-empty"><div class="empty-icon">⌕</div><h3>No service found</h3><p>Try another search term or browse a service area.</p><a class="button button-outline" href="<?php echo e(route('public.services.index')); ?>">Browse all services</a></div>
        <?php endif; ?>

    <?php elseif(!$selectedCategory): ?>
        <div class="catalog-intro-row">
            <div><span class="eyebrow">COMPLETE CATALOGUE</span><h2>All service areas.</h2></div>
            <p>We have grouped every service by purpose, so you can see the full range without a long flat list.</p>
        </div>

        <div class="catalog-all-pillars">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $pillarServices = $category->children->sum(fn($child) => $child->active_services_count) + $category->active_services_count;
                ?>
                <section class="catalog-pillar-section">
                    <div class="catalog-pillar-heading">
                        <div class="catalog-pillar-heading-icon"><?php echo $__env->make('partials.icon', ['iconKey' => $categoryIcon($category)], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>
                        <div class="catalog-pillar-heading-copy">
                            <span class="eyebrow"><?php echo e(str_pad($loop->iteration,2,'0',STR_PAD_LEFT)); ?> · SERVICE PILLAR</span>
                            <h2><?php echo e($category->name); ?></h2>
                            <p><?php echo e($category->description); ?></p>
                            <span class="catalog-pillar-count"><?php echo e($pillarServices); ?> services in this pillar</span>
                        </div>
                        <a class="button button-outline" href="<?php echo e(route('public.services.index',['category'=>$category->slug])); ?>">Explore pillar →</a>
                    </div>

                    <?php if($category->children->isNotEmpty()): ?>
                        <div class="catalog-group-grid">
                            <?php $__currentLoopData = $category->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="catalog-group-card" href="<?php echo e(route('public.services.index',['category'=>$child->slug])); ?>">
                                    <div class="catalog-group-icon"><?php echo $__env->make('partials.icon', ['iconKey' => $categoryIcon($child)], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>
                                    <div class="catalog-group-copy"><span class="catalog-group-kicker"><?php echo e(str_pad($loop->iteration,2,'0',STR_PAD_LEFT)); ?></span><h3><?php echo e($child->name); ?></h3><p><?php echo e($child->description ?: 'Explore services in this group.'); ?></p></div>
                                    <div class="catalog-group-footer"><span><?php echo e($child->active_services_count); ?> <?php echo e($child->active_services_count === 1 ? 'service' : 'services'); ?></span><strong>Open →</strong></div>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <div class="catalog-featured-services">
                            <div class="catalog-subhead"><div><span class="eyebrow">POPULAR IN <?php echo e(strtoupper($category->name)); ?></span><h3>Start with a service</h3></div><a class="catalog-view-all" href="<?php echo e(route('public.services.index',['category'=>$category->slug])); ?>">View all <?php echo e($pillarServices); ?> services →</a></div>
                            <div class="service-grid service-grid-premium">
                                <?php $__currentLoopData = $category->children->flatMap(fn($child) => $child->services)->take(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo $__env->make('services.partials.card', ['service' => $service], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php elseif($category->services->where('is_active',true)->isNotEmpty()): ?>
                        <div class="catalog-featured-services">
                            <div class="catalog-subhead"><div><span class="eyebrow">SERVICES</span><h3>Available services</h3></div><a class="catalog-view-all" href="<?php echo e(route('public.services.index',['category'=>$category->slug])); ?>">View all <?php echo e($pillarServices); ?> services →</a></div>
                            <div class="service-grid service-grid-premium">
                                <?php $__currentLoopData = $category->services->where('is_active',true)->take(6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo $__env->make('services.partials.card', ['service' => $service], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </section>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    <?php elseif($selectedCategory->isTopLevel()): ?>
        <?php if($childCategories->isNotEmpty()): ?>
            <div class="catalog-intro-row"><div><span class="eyebrow"><?php echo e($selectedCategory->name); ?></span><h2>Choose a group.</h2></div><p>Every group below opens into the specific services available there.</p></div>
            <div class="catalog-group-grid">
                <?php $__currentLoopData = $childCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="catalog-group-card" href="<?php echo e(route('public.services.index', ['category' => $child->slug])); ?>"><div class="catalog-group-icon"><?php echo $__env->make('partials.icon',['iconKey'=>$categoryIcon($child)], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div><div class="catalog-group-copy"><span class="catalog-group-kicker"><?php echo e(str_pad($loop->iteration,2,'0',STR_PAD_LEFT)); ?></span><h3><?php echo e($child->name); ?></h3><p><?php echo e($child->description ?: 'Explore services in this group.'); ?></p></div><div class="catalog-group-footer"><span><?php echo e($child->active_services_count); ?> services</span><strong>Open →</strong></div></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
        <?php if($services->isNotEmpty()): ?>
            <div class="catalog-section direct-services"><div class="catalog-section-head"><div><span class="eyebrow">SERVICES</span><h2>Available directly here</h2></div><span class="section-count"><?php echo e($services->count()); ?> services</span></div><div class="service-grid service-grid-premium"><?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo $__env->make('services.partials.card',['service'=>$service], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div></div>
        <?php endif; ?>

    <?php else: ?>
        <div class="catalog-section child-service-section"><div class="catalog-section-head"><div><span class="eyebrow"><?php echo e($selectedCategory->parent?->name ?? 'SERVICE GROUP'); ?></span><h2><?php echo e($selectedCategory->name); ?></h2><p>Choose the exact service you need and we'll guide you through the application.</p></div><span class="section-count"><?php echo e($services->count()); ?> services</span></div><?php if($services->isNotEmpty()): ?><div class="service-grid service-grid-premium"><?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo $__env->make('services.partials.card',['service'=>$service], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div><?php else: ?><div class="catalog-empty compact"><h3>No active services in this group yet.</h3><a class="button button-outline" href="<?php echo e(route('public.services.index')); ?>">Back to service areas</a></div><?php endif; ?></div>
    <?php endif; ?>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\DIGITAL STAR\digital-star-consultants\resources\views/services/index.blade.php ENDPATH**/ ?>