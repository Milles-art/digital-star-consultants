<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e($title ?? 'Digital Star · Admin'); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css','resources/js/app.js']); ?>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body class="admin-body">
<?php
    $adminUnreadCount = \Illuminate\Support\Facades\Schema::hasTable('notifications')
        ? auth()->user()->unreadNotifications()->count()
        : 0;
?>
<button class="admin-mobile-toggle" type="button" aria-label="Open navigation" aria-expanded="false" data-admin-menu-toggle><span></span><span></span><span></span></button>
<div class="admin-shell-overlay" data-admin-overlay></div>
<aside class="admin-sidebar" data-admin-sidebar>
    <a class="brand admin-brand" href="<?php echo e(route('admin.dashboard')); ?>" aria-label="Digital Star Consultants administration">
        <span class="brand-mark"><img src="<?php echo e(asset('images/digital-star-mark.svg')); ?>" alt="Digital Star Consultants star mark"></span><span><b>DIGITAL STAR</b><small>OPERATIONS</small></span>
    </a>
    <div class="admin-workspace-label"><span class="admin-avatar"><?php echo e(strtoupper(substr(auth()->user()->name,0,1))); ?></span><div><strong><?php echo e(auth()->user()->name); ?></strong><small><?php echo e(auth()->user()->role_label); ?></small></div></div>
    <nav aria-label="Admin navigation">
        <span class="nav-label">OVERVIEW</span>
        <a class="<?php echo e(request()->routeIs('admin.dashboard')?'active':''); ?>" href="<?php echo e(route('admin.dashboard')); ?>"><span class="nav-icon">⌂</span>Dashboard</a>
        <a class="<?php echo e(request()->routeIs('admin.notifications.*')?'active':''); ?>" href="<?php echo e(route('admin.notifications.index')); ?>"><span class="nav-icon">◔</span>Notifications <?php if($adminUnreadCount): ?><span class="admin-nav-badge"><?php echo e($adminUnreadCount); ?></span><?php endif; ?></a>
        <span class="nav-label">SERVICE OPERATIONS</span>
        <a class="<?php echo e(request()->routeIs('admin.submissions.*')?'active':''); ?>" href="<?php echo e(route('admin.submissions.index')); ?>"><span class="nav-icon">◫</span>Requests</a>
        <a class="<?php echo e(request()->routeIs('admin.categories.*')?'active':''); ?>" href="<?php echo e(route('admin.categories.index')); ?>"><span class="nav-icon">▦</span>Categories</a>
        <a class="<?php echo e(request()->routeIs('admin.services.*','admin.fields.*')?'active':''); ?>" href="<?php echo e(route('admin.services.index')); ?>"><span class="nav-icon">✦</span>Services</a>
        <span class="nav-label">INSIGHTS</span>
        <a class="<?php echo e(request()->routeIs('admin.reports.*')?'active':''); ?>" href="<?php echo e(route('admin.reports.index')); ?>"><span class="nav-icon">◌</span>Reports</a>
        <a class="<?php echo e(request()->routeIs('admin.finance.*')?'active':''); ?>" href="<?php echo e(route('admin.finance.index')); ?>"><span class="nav-icon">◈</span>Finance</a>
        <a class="<?php echo e(request()->routeIs('admin.contact-messages.*')?'active':''); ?>" href="<?php echo e(route('admin.contact-messages.index')); ?>"><span class="nav-icon">✉</span>Messages</a>
        <span class="nav-label">TEAM</span>
        <a class="<?php echo e(request()->routeIs('admin.users.*')?'active':''); ?>" href="<?php echo e(route('admin.users.index')); ?>"><span class="nav-icon">◎</span>Users</a>
        <a class="<?php echo e(request()->routeIs('admin.settings.*')?'active':''); ?>" href="<?php echo e(route('admin.settings.index')); ?>"><span class="nav-icon">⚙</span>Settings</a>
    </nav>
    <div class="admin-sidebar-footer"><a class="admin-site-link" href="<?php echo e(route('home')); ?>"><span>↗</span>View website</a><form method="POST" action="<?php echo e(route('admin.logout')); ?>"><?php echo csrf_field(); ?><button type="submit" class="admin-logout-link">Sign out</button></form></div>
</aside>
<main class="admin-main">
<header class="admin-top">
    <div class="admin-title-wrap"><div class="admin-breadcrumb"><span>Digital Star</span><b>/</b><span><?php echo e(ucfirst(str_replace('-',' ',request()->segment(2) ?: 'dashboard'))); ?></span></div><h1><?php echo $__env->yieldContent('page_title','Dashboard'); ?></h1></div>
    <div class="admin-top-actions"><a class="admin-notification-bell" href="<?php echo e(route('admin.notifications.index')); ?>" aria-label="Notifications">◔ <?php if($adminUnreadCount): ?><span><?php echo e($adminUnreadCount); ?></span><?php endif; ?></a><a class="admin-view-site" href="<?php echo e(route('home')); ?>" target="_blank" rel="noopener">Open website <span>↗</span></a><div class="admin-user-menu"><span class="admin-avatar admin-avatar-small"><?php echo e(strtoupper(substr(auth()->user()->name,0,1))); ?></span><div><strong><?php echo e(auth()->user()->name); ?></strong><small><?php echo e(auth()->user()->role_label); ?></small></div></div></div>
</header>
<?php if(session('success')): ?><div class="flash success" role="status"><?php echo e(session('success')); ?></div><?php endif; ?>
<?php if(session('error')): ?><div class="flash error" role="alert"><?php echo e(session('error')); ?></div><?php endif; ?>
<?php if($errors->any()): ?><div class="flash error" role="alert"><?php echo e($errors->first()); ?></div><?php endif; ?>
<?php echo $__env->yieldContent('content'); ?>
</main>
<?php echo $__env->yieldPushContent('scripts'); ?>
<script>
(()=>{const s=document.querySelector('[data-admin-sidebar]'),t=document.querySelector('[data-admin-menu-toggle]'),o=document.querySelector('[data-admin-overlay]');if(!s||!t||!o)return;const setOpen=v=>{s.classList.toggle('is-open',v);o.classList.toggle('is-visible',v);t.setAttribute('aria-expanded',v?'true':'false')};t.addEventListener('click',()=>setOpen(!s.classList.contains('is-open')));o.addEventListener('click',()=>setOpen(false));s.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>setOpen(false)));})();
</script>
</body></html>
<?php /**PATH C:\Users\DIGITAL STAR\digital-star-consultants\resources\views/layouts/admin.blade.php ENDPATH**/ ?>