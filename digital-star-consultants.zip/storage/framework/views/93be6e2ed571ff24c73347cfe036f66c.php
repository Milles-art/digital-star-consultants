<?php $__env->startSection('page_title', 'Application '.$submission->reference_number); ?>
<?php $__env->startSection('content'); ?>
<?php
    $statusClass = match ($submission->status) {
        \App\Models\Submission::STATUS_COMPLETED => 'success',
        \App\Models\Submission::STATUS_REJECTED => 'danger',
        \App\Models\Submission::STATUS_IN_PROGRESS => 'info',
        \App\Models\Submission::STATUS_AWAITING_CUSTOMER => 'secondary',
        default => 'warning',
    };

    $serviceFields = $submission->service?->fields?->sortBy('sort_order') ?? collect();
    $valuesByField = $submission->values->keyBy('service_field_id');
    $submittedDynamicValues = $submission->values->filter(function ($value) {
        return $value->isFile() ? $value->hasFile() : filled($value->value);
    });
    $fileValues = $submission->values->filter(fn ($value) => $value->isFile());
    $providedCount = $serviceFields->filter(function ($field) use ($valuesByField) {
        $value = $valuesByField->get($field->id);
        return $value && ($value->isFile() ? $value->hasFile() : filled($value->value));
    })->count();
    $requiredMissingCount = $serviceFields->where('is_required', true)->filter(function ($field) use ($valuesByField) {
        $value = $valuesByField->get($field->id);
        return ! $value || ($value->isFile() ? ! $value->hasFile() : blank($value->value));
    })->count();

    $steps = [
        ['label' => 'Received', 'caption' => 'Request received', 'complete' => true],
        ['label' => 'In Progress', 'caption' => 'Staff review & processing', 'complete' => in_array($submission->status, [\App\Models\Submission::STATUS_IN_PROGRESS, \App\Models\Submission::STATUS_AWAITING_CUSTOMER, \App\Models\Submission::STATUS_COMPLETED], true)],
        ['label' => 'Customer Action', 'caption' => 'Information may be needed', 'complete' => $submission->status === \App\Models\Submission::STATUS_AWAITING_CUSTOMER, 'current' => $submission->status === \App\Models\Submission::STATUS_AWAITING_CUSTOMER],
        ['label' => 'Completed', 'caption' => 'Service completed', 'complete' => $submission->status === \App\Models\Submission::STATUS_COMPLETED],
    ];
?>

<div class="dsc-request-page">
    <div class="dsc-request-topbar">
        <div class="dsc-request-crumbs">
            <a href="<?php echo e(route('admin.submissions.index')); ?>">Requests</a><span>/</span><strong><?php echo e($submission->reference_number); ?></strong>
        </div>
        <div class="dsc-request-actions">
            <a class="dsc-request-secondary" href="<?php echo e(route('public.track.show', ['reference' => $submission->reference_number])); ?>" target="_blank" rel="noopener">Customer view <span>↗</span></a>
            <a class="dsc-request-secondary" href="<?php echo e(route('admin.submissions.print', $submission)); ?>" target="_blank" rel="noopener">Print / Save PDF <span>↗</span></a>
        </div>
    </div>

    <section class="dsc-request-hero">
        <div class="dsc-request-hero-main">
            <span class="dsc-request-overline"><?php echo e($submission->service?->category?->full_path ?? $submission->service?->category?->name ?? 'Service request'); ?></span>
            <div class="dsc-request-title-line">
                <h2><?php echo e($submission->service->name ?? 'Service request'); ?></h2>
                <span class="badge <?php echo e($statusClass); ?>"><?php echo e($submission->status_label); ?></span>
            </div>
            <p>Reference <strong><?php echo e($submission->reference_number); ?></strong><span>•</span> Submitted <?php echo e($submission->created_at?->format('d M Y, H:i')); ?></p>
        </div>
        <div class="dsc-request-hero-stats">
            <div><span>REQUEST OWNER</span><strong><?php echo e($submission->processedBy->name ?? 'Unassigned'); ?></strong></div>
            <div><span>PAYMENT</span><strong><?php echo e(ucfirst($submission->payment_status ?? 'Pending')); ?></strong></div>
            <div><span>TOTAL</span><strong><?php echo e($submission->total_price !== null ? number_format((float)$submission->total_price, 2).' TZS' : 'Not set'); ?></strong></div>
        </div>
    </section>

    <section class="dsc-workflow-card">
        <div class="dsc-card-title-row">
            <div><span class="dsc-card-kicker">WORKFLOW</span><h3>Application progress</h3></div>
            <span class="dsc-card-state"><?php echo e($submission->status_label); ?></span>
        </div>
        <div class="dsc-workflow">
            <?php $__currentLoopData = $steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="dsc-workflow-step <?php echo e(!empty($step['complete']) ? 'is-complete' : ''); ?> <?php echo e(!empty($step['current']) ? 'is-current' : ''); ?>">
                    <span class="dsc-workflow-dot"><?php echo e(!empty($step['complete']) && empty($step['current']) ? '✓' : $loop->iteration); ?></span>
                    <div><strong><?php echo e($step['label']); ?></strong><small><?php echo e($step['caption']); ?></small></div>
                </div>
                <?php if(!$loop->last): ?><div class="dsc-workflow-line"></div><?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>

    <div class="dsc-request-layout">
        <main class="dsc-request-main">
            <section class="dsc-panel dsc-customer-panel">
                <div class="dsc-card-title-row">
                    <div><span class="dsc-card-kicker">CUSTOMER SUBMISSION</span><h3>Information received from customer</h3></div>
                    <div class="dsc-answer-summary"><strong><?php echo e($providedCount); ?></strong><span>of <?php echo e($serviceFields->count()); ?> fields provided</span></div>
                </div>

                <div class="dsc-customer-grid">
                    <div class="dsc-info-card">
                        <div class="dsc-info-card-head"><span class="dsc-info-icon">◎</span><div><strong>Customer details</strong><small>Information entered at checkout</small></div></div>
                        <div class="dsc-info-rows">
                            <div><span>Full name</span><strong><?php echo e($submission->customer_name ?: 'Not provided'); ?></strong></div>
                            <div><span>Phone</span><strong><?php echo e($submission->customer_phone ?: 'Not provided'); ?></strong></div>
                            <div><span>Email</span><strong><?php echo e($submission->customer_email ?: 'Not provided'); ?></strong></div>
                            <div><span>Preferred date</span><strong><?php echo e($submission->preferred_date?->format('d M Y') ?? 'Not specified'); ?></strong></div>
                            <div><span>Reference</span><strong><?php echo e($submission->reference_number); ?></strong></div>
                        </div>
                    </div>

                    <div class="dsc-info-card">
                        <div class="dsc-info-card-head"><span class="dsc-info-icon is-gold">▣</span><div><strong>Request summary</strong><small>Operational information</small></div></div>
                        <div class="dsc-info-rows">
                            <div><span>Service</span><strong><?php echo e($submission->service->name ?? '—'); ?></strong></div>
                            <div><span>Category</span><strong><?php echo e($submission->service?->category?->name ?? '—'); ?></strong></div>
                            <div><span>Assigned to</span><strong><?php echo e($submission->processedBy->name ?? 'Unassigned'); ?></strong></div>
                            <div><span>Payment</span><strong><?php echo e(ucfirst($submission->payment_status ?? 'Pending')); ?></strong></div>
                            <div><span>Total price</span><strong><?php echo e($submission->total_price !== null ? number_format((float)$submission->total_price, 2).' TZS' : 'Not set'); ?></strong></div>
                        </div>
                    </div>
                </div>

                <div class="dsc-submitted-head">
                    <div><span class="dsc-card-kicker">SERVICE INFORMATION</span><h4>Submitted service answers</h4></div>
                    <div class="dsc-missing-pill <?php echo e($requiredMissingCount ? 'has-missing' : 'is-good'); ?>"><?php echo e($requiredMissingCount); ?> required missing</div>
                </div>

                <?php if($serviceFields->isNotEmpty()): ?>
                    <div class="dsc-answer-list">
                        <?php $__currentLoopData = $serviceFields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $value = $valuesByField->get($field->id);
                                $hasValue = $value && ($value->isFile() ? $value->hasFile() : filled($value->value));
                                $display = $value ? $value->getValueForDisplay() : null;
                            ?>
                            <div class="dsc-answer-row <?php echo e($hasValue ? 'has-value' : 'is-missing'); ?>">
                                <div class="dsc-answer-label"><strong><?php echo e($field->label); ?></strong><?php if($field->is_required): ?><span>Required</span><?php endif; ?></div>
                                <div class="dsc-answer-value">
                                    <?php if($hasValue): ?>
                                        <?php if($value->isFile()): ?>
                                            <a class="dsc-inline-file" href="<?php echo e(route('admin.submissions.files.download', [$submission, $value])); ?>"><span>PDF</span><?php echo e($display); ?> <b>↗</b></a>
                                        <?php else: ?>
                                            <?php echo e($display ?: 'Blank'); ?>

                                        <?php endif; ?>
                                    <?php else: ?>
                                        <span class="dsc-not-provided">Not provided</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php else: ?>
                    <div class="dsc-empty-box">This service has no configured service-specific fields.</div>
                <?php endif; ?>

                <div class="dsc-customer-message">
                    <div><span class="dsc-info-icon is-message">✦</span><div><strong>Customer message</strong><small>Additional notes submitted with this request</small></div></div>
                    <p><?php echo e($submission->customer_notes ?: 'No additional message was submitted by the customer.'); ?></p>
                </div>
            </section>

            <section class="dsc-panel">
                <div class="dsc-card-title-row">
                    <div><span class="dsc-card-kicker">DOCUMENTS</span><h3>Uploaded documents</h3></div>
                    <span class="dsc-card-state"><?php echo e($fileValues->count()); ?> files</span>
                </div>
                <?php if($fileValues->isNotEmpty()): ?>
                    <div class="dsc-document-list">
                        <?php $__currentLoopData = $fileValues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="dsc-document-row">
                                <div class="dsc-document-icon">PDF</div>
                                <div class="dsc-document-copy"><strong><?php echo e($value->field->label ?? 'Uploaded document'); ?></strong><span><?php echo e($value->display_value); ?><?php echo e($value->file_size ? ' · '.$value->file_size : ''); ?></span></div>
                                <a href="<?php echo e(route('admin.submissions.files.download', [$submission, $value])); ?>">Download <span>↓</span></a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php else: ?>
                    <div class="dsc-empty-box">No documents were uploaded with this request.</div>
                <?php endif; ?>
            </section>

            <section class="dsc-panel">
                <div class="dsc-card-title-row"><div><span class="dsc-card-kicker">ACTIVITY</span><h3>Request history</h3></div><span class="dsc-card-state"><?php echo e($submission->activities->count()); ?> events</span></div>
                <?php if($submission->activities->isNotEmpty()): ?>
                    <div class="dsc-activity-list">
                        <?php $__currentLoopData = $submission->activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <article class="dsc-activity-row">
                                <div class="dsc-activity-marker"></div>
                                <div><strong><?php echo e($activity->title); ?></strong><?php if($activity->description): ?><p><?php echo e($activity->description); ?></p><?php endif; ?><small><?php echo e($activity->created_at?->format('d M Y, H:i')); ?> <span>·</span> <?php echo e($activity->user->name ?? 'Customer'); ?></small></div>
                            </article>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php else: ?>
                    <div class="dsc-empty-box">No activity has been recorded yet.</div>
                <?php endif; ?>
            </section>

            <section class="dsc-panel dsc-internal-panel" id="edit-details">
                <div class="dsc-card-title-row"><div><span class="dsc-card-kicker">INTERNAL</span><h3>Staff workspace</h3></div><span class="dsc-card-state">Private</span></div>
                <form method="POST" action="<?php echo e(route('admin.submissions.update', $submission)); ?>" class="dsc-internal-form">
                    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                    <div class="dsc-field-grid">
                        <label><span>Customer name</span><input name="customer_name" value="<?php echo e($submission->customer_name); ?>"></label>
                        <label><span>Phone</span><input name="customer_phone" value="<?php echo e($submission->customer_phone); ?>"></label>
                        <label><span>Email</span><input type="email" name="customer_email" value="<?php echo e($submission->customer_email); ?>"></label>
                        <label><span>Preferred date</span><input type="date" name="preferred_date" value="<?php echo e($submission->preferred_date?->format('Y-m-d')); ?>"></label>
                        <label><span>Total price (TZS)</span><input type="number" step="0.01" min="0" name="total_price" value="<?php echo e($submission->total_price); ?>"></label>
                        <label class="full"><span>Internal staff notes</span><textarea name="staff_notes" rows="5" placeholder="Add private processing notes, follow-ups or handover details..."><?php echo e($submission->staff_notes); ?></textarea></label>
                    </div>
                    <button class="dsc-primary-action" type="submit">Save changes</button>
                </form>
            </section>
        </main>

        <aside class="dsc-request-sidebar">
            <section class="dsc-side-card">
                <span class="dsc-side-kicker">ASSIGNMENT</span><h3>Request owner</h3>
                <form method="POST" action="<?php echo e(route('admin.submissions.assign', $submission)); ?>" class="dsc-side-form">
                    <?php echo csrf_field(); ?>
                    <select name="staff_id" required><option value="">Choose staff member…</option><?php $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($person->id); ?>" <?php if($submission->processed_by === $person->id): echo 'selected'; endif; ?>><?php echo e($person->name); ?> · <?php echo e($person->role_label); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select>
                    <button class="dsc-primary-action" type="submit">Assign request</button>
                </form>
            </section>

            <section class="dsc-side-card">
                <span class="dsc-side-kicker">NEXT ACTION</span><h3>Update status</h3>
                <div class="dsc-side-actions">
                    <form method="POST" action="<?php echo e(route('admin.submissions.in-progress', $submission)); ?>"><?php echo csrf_field(); ?><button type="submit"><i class="is-blue">↗</i><span><strong>Start processing</strong><small>Move into active work.</small></span></button></form>
                    <form method="POST" action="<?php echo e(route('admin.submissions.awaiting-customer', $submission)); ?>"><?php echo csrf_field(); ?><input type="hidden" name="reason" value="Additional information is required to continue processing this request."><button type="submit"><i class="is-gold">?</i><span><strong>Await customer</strong><small>Pause until information arrives.</small></span></button></form>
                    <form method="POST" action="<?php echo e(route('admin.submissions.complete', $submission)); ?>"><?php echo csrf_field(); ?><button type="submit"><i class="is-green">✓</i><span><strong>Mark completed</strong><small>Close the request.</small></span></button></form>
                </div>
            </section>

            <section class="dsc-side-card is-danger">
                <span class="dsc-side-kicker">EXCEPTION</span><h3>Reject request</h3>
                <form method="POST" action="<?php echo e(route('admin.submissions.reject', $submission)); ?>" class="dsc-side-form"><?php echo csrf_field(); ?><textarea name="reason" rows="4" placeholder="Reason for rejection…"></textarea><button class="dsc-danger-action" type="submit">Reject request</button></form>
            </section>

            <section class="dsc-side-card">
                <span class="dsc-side-kicker">REQUEST DETAILS</span><h3>Record</h3>
                <dl class="dsc-record-list">
                    <div><dt>Reference</dt><dd><?php echo e($submission->reference_number); ?></dd></div>
                    <div><dt>Service</dt><dd><?php echo e($submission->service->name ?? '—'); ?></dd></div>
                    <div><dt>Created</dt><dd><?php echo e($submission->created_at?->format('d M Y, H:i')); ?></dd></div>
                    <div><dt>Updated</dt><dd><?php echo e($submission->updated_at?->format('d M Y, H:i')); ?></dd></div>
                    <?php if($submission->completed_at): ?><div><dt>Completed</dt><dd><?php echo e($submission->completed_at->format('d M Y, H:i')); ?></dd></div><?php endif; ?>
                </dl>
            </section>
        </aside>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\DIGITAL STAR\digital-star-consultants\resources\views/admin/submissions/show.blade.php ENDPATH**/ ?>