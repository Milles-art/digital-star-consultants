<?php $__env->startSection('content'); ?>
<section class="works-page">
    <div class="works-hero">
        <div class="works-hero-inner">
            <div class="works-hero-copy">
                <div class="works-eyebrow">OUR WORKS</div>
                <h1>We build solutions<br><em>that drive success.</em></h1>
                <p>Explore a selection of our IT solutions, software projects and creative design work that help businesses grow and stand out.</p>
                <a class="ds-button ds-button-gold" href="#featured-projects">View all projects <span>→</span></a>
            </div>
            <div class="works-hero-stage" data-work-slideshow>
                <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article class="work-slide <?php echo e($i === 0 ? 'is-active' : ''); ?>" data-slide="<?php echo e($i); ?>" aria-hidden="<?php echo e($i === 0 ? 'false' : 'true'); ?>">
                        <img src="<?php echo e(asset($slide['image'])); ?>" alt="<?php echo e($slide['title']); ?> project preview" loading="<?php echo e($i === 0 ? 'eager' : 'lazy'); ?>">
                        <div class="work-slide-overlay">
                            <span><?php echo e($slide['category']); ?></span>
                            <strong><?php echo e($slide['title']); ?></strong>
                        </div>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <button class="work-slide-arrow prev" type="button" aria-label="Previous project" data-slide-prev>←</button>
                <button class="work-slide-arrow next" type="button" aria-label="Next project" data-slide-next>→</button>
                <div class="work-slide-dots" role="tablist" aria-label="Featured projects">
                    <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <button type="button" class="<?php echo e($i === 0 ? 'is-active' : ''); ?>" data-slide-dot="<?php echo e($i); ?>" aria-label="Show <?php echo e($slide['title']); ?>" aria-selected="<?php echo e($i === 0 ? 'true' : 'false'); ?>"></button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>

    <section class="works-featured" id="featured-projects">
        <div class="works-container">
            <div class="works-section-head">
                <div>
                    <div class="works-eyebrow">OUR PORTFOLIO</div>
                    <h2>Featured projects</h2>
                </div>
                <p>IT systems, software and creative work presented in one place.</p>
            </div>

            <div class="works-filter" role="tablist" aria-label="Project categories">
                <button class="is-active" type="button" data-work-filter="all">All projects</button>
                <button type="button" data-work-filter="it">IT &amp; Technology</button>
                <button type="button" data-work-filter="software">Software &amp; Web</button>
                <button type="button" data-work-filter="graphics">Graphics &amp; Branding</button>
            </div>

            <div class="works-project-grid">
                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article class="works-project-card" data-project-category="<?php echo e($project['filter']); ?>">
                        <button type="button" class="works-project-image works-project-trigger" data-project-id="<?php echo e($loop->index); ?>" aria-label="Open <?php echo e($project['title']); ?> case study">
                            <img src="<?php echo e(asset($project['image'])); ?>" alt="<?php echo e($project['title']); ?> preview" loading="lazy">
                            <span class="works-project-tag"><?php echo e($project['category']); ?></span>
                        </button>
                        <div class="works-project-copy">
                            <h3><?php echo e($project['title']); ?></h3>
                            <p><?php echo e($project['description']); ?></p>
                            <div class="works-project-meta">
                                <?php $__currentLoopData = $project['meta']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span><?php echo e($tag); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <button type="button" class="works-project-link works-project-trigger" data-project-id="<?php echo e($loop->index); ?>">View case study <span>→</span></button>
                        </div>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="works-modal" data-work-modal aria-hidden="true">
                <div class="works-modal-backdrop" data-modal-close></div>
                <div class="works-modal-dialog" role="dialog" aria-modal="true" aria-labelledby="works-modal-title">
                    <button type="button" class="works-modal-close" data-modal-close aria-label="Close case study">×</button>
                    <img data-modal-image src="" alt="">
                    <div class="works-modal-content">
                        <div class="works-eyebrow" data-modal-category></div>
                        <h2 id="works-modal-title" data-modal-title></h2>
                        <p data-modal-description></p>
                        <div class="works-project-meta" data-modal-meta></div>
                        <a class="ds-button ds-button-gold" href="<?php echo e(route('public.contact.show')); ?>">Discuss a similar project <span>→</span></a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="works-cta">
        <div class="works-container works-cta-inner">
            <div>
                <div class="works-eyebrow">HAVE A PROJECT IN MIND?</div>
                <h2>Let's build something<br><em>amazing together.</em></h2>
            </div>
            <a href="<?php echo e(route('public.contact.show')); ?>" class="ds-button ds-button-gold">Start your project <span>→</span></a>
        </div>
    </section>

    <section class="works-stats">
        <div class="works-container works-stats-grid">
            <?php $__currentLoopData = $stats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="works-stat">
                    <strong><?php echo e($stat['value']); ?></strong>
                    <span><?php echo e($stat['label']); ?></span>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
</section>
<script>
window.digitalStarProjects = <?php echo json_encode($projects, 15, 512) ?>;
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\DIGITAL STAR\digital-star-consultants\resources\views/work.blade.php ENDPATH**/ ?>