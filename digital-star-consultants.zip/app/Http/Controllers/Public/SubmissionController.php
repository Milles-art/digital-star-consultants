<?php

namespace App\Http\Controllers\Public;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreSubmissionRequest;
use App\Models\Service;
use App\Models\Submission;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class SubmissionController extends Controller
{
    protected $submissionService;

    public function __construct(\App\Services\SubmissionService $submissionService)
    {
        $this->submissionService = $submissionService;
    }

    public function store(StoreSubmissionRequest $request): JsonResponse
    {
        $service = Service::with('fields')->find($request->service_id);

        if (! $service || ! $service->is_active) {
            return response()->json([
                'status' => 'error',
                'message' => 'Service not available',
            ], 404);
        }

        $fieldRules = [];
        foreach ($service->fields as $field) {
            $fieldRules["fields.{$field->field_key}"] = $field->getValidationRules();
        }

        // Validate one canonical field bag. Laravel keeps uploaded files in the
        // file bag; merge them into the same nested `fields` structure used by
        // text/select/radio inputs so every seeded field is validated exactly once.
        $payload = $request->all();
        $payload['fields'] = array_replace_recursive(
            is_array($request->input('fields', [])) ? $request->input('fields', []) : [],
            is_array($request->file('fields', [])) ? $request->file('fields', []) : []
        );

        Validator::make($payload, $fieldRules)->validate();

        try {
            $submission = $this->submissionService->createSubmission($service, [
                'customer_name' => $request->validated('customer_name'),
                'customer_phone' => $request->validated('customer_phone'),
                'customer_email' => $request->validated('customer_email'),
                'customer_notes' => $request->validated('customer_notes'),
                'preferred_date' => $request->validated('preferred_date'),
                'fields' => $request->input('fields', []),
                'files' => $request->file('fields', []),
            ]);

            return response()->json([
                'status' => 'success',
                'message' => 'Submission created successfully',
                'data' => [
                    'reference_number' => $submission->reference_number,
                    'status' => $submission->status,
                    'status_label' => $submission->status_label,
                    'tracking_url' => url("/track/{$submission->reference_number}"),
                    'customer_name' => $submission->customer_name,
                    'service_name' => $service->name,
                ],
            ], 201);

        } catch (\Exception $e) {
            Log::error('Submission creation failed', [
                'exception' => $e->getMessage(),
                'service_id' => $service->id,
                'ip' => $request->ip(),
            ]);

            return response()->json([
                'status' => 'error',
                'message' => 'Unable to process your request. Please try again later.',
            ], 500);
        }
    }

    public function track(string $reference): JsonResponse
    {
        $submission = Submission::with(['service', 'values.field'])
            ->where('reference_number', $reference)
            ->first();

        if (! $submission) {
            return response()->json([
                'status' => 'error',
                'message' => 'Submission not found',
            ], 404);
        }

        $nameParts = preg_split('/\s+/', trim((string) $submission->customer_name), -1, PREG_SPLIT_NO_EMPTY);
        $maskedName = $nameParts[0] ?? 'Customer';

        return response()->json([
            'status' => 'success',
            'data' => [
                'reference_number' => $submission->reference_number,
                'status' => $submission->status,
                'status_label' => $submission->status_label,
                'status_color' => $submission->status_color,
                'service_name' => $submission->service->name ?? null,
                'customer_name' => $maskedName,
                'created_at' => $submission->created_at->format('Y-m-d H:i'),
                'completed_at' => $submission->completed_at?->format('Y-m-d H:i'),
            ],
        ]);
    }
}
