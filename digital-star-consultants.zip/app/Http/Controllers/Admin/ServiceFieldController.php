<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreServiceFieldRequest;
use App\Http\Requests\Admin\UpdateServiceFieldRequest;
use App\Http\Resources\ServiceFieldResource;
use App\Models\Service;
use App\Models\ServiceField;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\View\View;

class ServiceFieldController extends Controller
{
    public function index(Service $service): View|JsonResponse
    {
        $this->authorize('viewAny', ServiceField::class);

        $fields = $service->fields()->orderBy('sort_order')->get();

        if (! request()->expectsJson()) {
            $service->load('category');

            return view('admin.fields.index', [
                'service' => $service,
                'fields' => $fields,
                'fieldTypes' => ServiceField::TYPES,
            ]);
        }

        return response()->json([
            'status' => 'success',
            'data' => [
                'service' => [
                    'id' => $service->id,
                    'name' => $service->name,
                ],
                'fields' => ServiceFieldResource::collection($fields)
            ]
        ]);
    }

    public function store(StoreServiceFieldRequest $request, Service $service)
    {
        // Authorization already handled by StoreServiceFieldRequest::authorize()
        $validated = $request->validated();

        $fieldKey = Str::slug($validated['label'], '_');
        $originalKey = $fieldKey;
        $counter = 1;

        while ($service->fields()->where('field_key', $fieldKey)->exists()) {
            $fieldKey = $originalKey . '_' . $counter;
            $counter++;
        }

        $field = $service->fields()->create([
            'label' => $validated['label'],
            'field_key' => $fieldKey,
            'field_type' => $validated['field_type'],
            'options' => $validated['options'] ?? null,
            'placeholder' => $validated['placeholder'] ?? null,
            'help_text' => $validated['help_text'] ?? null,
            'default_value' => $validated['default_value'] ?? null,
            'is_required' => $validated['is_required'] ?? true,
            'sort_order' => $validated['sort_order'] ?? 0,
        ]);

        return response()->json([
            'status' => 'success',
            'message' => 'Field created successfully',
            'data' => new ServiceFieldResource($field)
        ], 201);
    }

    public function show(ServiceField $field)
    {
        $this->authorize('view', $field);

        $field->load('service');

        return response()->json([
            'status' => 'success',
            'data' => new ServiceFieldResource($field)
        ]);
    }

    public function update(UpdateServiceFieldRequest $request, ServiceField $field)
    {
        // Authorization already handled by UpdateServiceFieldRequest::authorize()
        $validated = $request->validated();

        if (!empty($validated['label']) && $validated['label'] !== $field->label) {
            $fieldKey = Str::slug($validated['label'], '_');
            $originalKey = $fieldKey;
            $counter = 1;

            while (ServiceField::where('service_id', $field->service_id)
                ->where('field_key', $fieldKey)
                ->where('id', '!=', $field->id)
                ->exists()) {
                $fieldKey = $originalKey . '_' . $counter;
                $counter++;
            }

            $validated['field_key'] = $fieldKey;
        }

        $field->update(array_filter($validated, fn ($value) => !is_null($value)));

        return response()->json([
            'status' => 'success',
            'message' => 'Field updated successfully',
            'data' => new ServiceFieldResource($field)
        ]);
    }

    public function destroy(ServiceField $field)
    {
        $this->authorize('delete', $field);

        // Service fields are part of the submission contract. Never hard-delete
        // them: historical submissions may still reference the field, and the
        // exact question definition should remain available to staff.
        $field->update(['is_active' => false]);

        return response()->json([
            'status' => 'success',
            'message' => 'Field archived successfully. Historical submissions remain intact.'
        ]);
    }

    public function reorder(Request $request)
    {
        $this->authorize('update', ServiceField::class);

        $validated = $request->validate([
            'fields' => ['required', 'array', 'min:1', 'max:200'],
            'fields.*.id' => ['required', 'integer', 'distinct', 'exists:service_fields,id'],
            'fields.*.sort_order' => ['required', 'integer', 'min:0', 'max:100000'],
        ]);

        $ids = collect($validated['fields'])->pluck('id');
        $found = ServiceField::whereIn('id', $ids)->count();
        if ($found !== $ids->count()) {
            return response()->json([
                'status' => 'error',
                'message' => 'One or more fields could not be found.',
            ], 422);
        }

        foreach ($validated['fields'] as $fieldData) {
            ServiceField::whereKey($fieldData['id'])
                ->update(['sort_order' => $fieldData['sort_order']]);
        }

        return response()->json([
            'status' => 'success',
            'message' => 'Fields reordered successfully'
        ]);
    }
}
