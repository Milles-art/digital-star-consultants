@extends('layouts.app')

@section('content')
@php
    $pillarMeta = [
        'online-government-services' => ['label' => 'Government & Online Services', 'icon' => 'government', 'tone' => 'blue', 'copy' => 'Government applications, identification, immigration, education and online forms.'],
        'business-services' => ['label' => 'Business Services', 'icon' => 'business', 'tone' => 'green', 'copy' => 'Company registration, tax, compliance, business documentation and support.'],
        'printing-graphics-design' => ['label' => 'Printing, Branding & Stationery', 'icon' => 'printing', 'tone' => 'gold', 'copy' => 'Professional printing, branding, stationery and creative production.'],
        'it-tech-consultancy' => ['label' => 'IT & Technology', 'icon' => 'it', 'tone' => 'purple', 'copy' => 'Websites, software, digital systems, technology consulting and support.'],
    ];
@endphp

<section class="dsc-home-hero">
    <div class="dsc-hero-backdrop"></div>
    <div class="dsc-hero-glow"></div>
    <div class="dsc-home-container dsc-hero-layout">
        <div class="dsc-hero-copy">
            <div class="dsc-eyebrow"><span class="dsc-eyebrow-dot"></span> DIGITAL SERVICES PARTNER · TANZANIA</div>
            <h1>Fast. Reliable.<br><span>Digital Services.</span></h1>
            <p>We help individuals and businesses complete government processes, business services, creative work and technology projects with less hassle.</p>
            <div class="dsc-hero-actions">
                <a class="dsc-btn dsc-btn-gold" href="{{ route('public.services.index') }}">Browse Services <span>→</span></a>
                <a class="dsc-btn dsc-btn-glass" href="{{ route('public.track.form') }}">Track Your Request <span>↗</span></a>
            </div>
            <div class="dsc-hero-trust-row">
                <div><strong>100+</strong><span>Services</span></div>
                <div><strong>Fast</strong><span>Processing</span></div>
                <div><strong>Secure</strong><span>Your data</span></div>
                <div><strong>Expert</strong><span>Support</span></div>
            </div>
        </div>
        <div class="dsc-hero-visual">
            <div class="dsc-city-card"></div>
            <div class="dsc-orbit orbit-a"></div>
            <div class="dsc-orbit orbit-b"></div>
            <div class="dsc-orbit orbit-c"></div>
            <div class="dsc-star-core"><span>DS</span></div>
            <div class="dsc-floating-chip chip-one"><b>01</b><span>Government</span></div>
            <div class="dsc-floating-chip chip-two"><b>02</b><span>Business</span></div>
            <div class="dsc-floating-chip chip-three"><b>03</b><span>Technology</span></div>
        </div>
    </div>
</section>

<section class="dsc-trust-bar">
    <div class="dsc-home-container dsc-trust-grid">
        <article><span class="dsc-trust-icon">✓</span><div><strong>Professional Assistance</strong><small>We handle the process for you.</small></div></article>
        <article><span class="dsc-trust-icon">◷</span><div><strong>Fast &amp; Reliable</strong><small>Clear updates and practical turnaround.</small></div></article>
        <article><span class="dsc-trust-icon">⌁</span><div><strong>Secure &amp; Private</strong><small>Your documents stay protected.</small></div></article>
        <article><span class="dsc-trust-icon">◉</span><div><strong>Dedicated Support</strong><small>Real help from start to finish.</small></div></article>
    </div>
</section>

<section class="dsc-section dsc-services-section">
    <div class="dsc-home-container">
        <div class="dsc-section-head">
            <div><span class="dsc-section-kicker">OUR SERVICES</span><h2>Everything you need.<br><em>In one place.</em></h2></div>
            <p>Start with one of our main service pillars, then choose the exact category and service you need. No overwhelming flat list.</p>
        </div>

        <div class="dsc-pillar-grid">
            @foreach($categories->take(4) as $category)
                @php
                    $meta = $pillarMeta[$category->slug] ?? ['label' => $category->name, 'icon' => 'forms', 'tone' => 'blue', 'copy' => $category->description ?: 'Professional services and guided assistance.'];
                    $count = $category->children->sum(fn($child) => $child->active_services_count) + $category->active_services_count;
                @endphp
                <a class="dsc-pillar" href="{{ route('public.services.index', ['category' => $category->slug]) }}">
                    <div class="dsc-pillar-top"><span class="dsc-pillar-num">{{ str_pad($loop->iteration, 2, '0', STR_PAD_LEFT) }}</span><span class="dsc-pillar-arrow">↗</span></div>
                    <span class="dsc-pillar-icon tone-{{ $meta['tone'] }}">@include('partials.icon',['iconKey'=>$meta['icon']])</span>
                    <h3>{{ $meta['label'] }}</h3>
                    <p>{{ $meta['copy'] }}</p>
                    <div class="dsc-pillar-foot"><span>{{ $category->children->count() }} {{ $category->children->count() === 1 ? 'category' : 'categories' }}</span><strong>{{ $count }} services →</strong></div>
                </a>
            @endforeach
        </div>
    </div>
</section>

<section class="dsc-section dsc-process-section">
    <div class="dsc-home-container">
        <div class="dsc-section-head compact"><div><span class="dsc-section-kicker">HOW IT WORKS</span><h2>Simple for you.<br><em>Structured for us.</em></h2></div><p>From first click to completed request, the workflow stays clear and trackable.</p></div>
        <div class="dsc-process-grid">
            @foreach($steps as $step)
                <article><span class="process-num">{{ $step['n'] }}</span><div class="process-icon">{{ ['◎','▣','◌','✓'][$loop->index] }}</div><h3>{{ $step['title'] }}</h3><p>{{ $step['desc'] }}</p></article>
            @endforeach
        </div>
    </div>
</section>

<section class="dsc-section dsc-popular-section">
    <div class="dsc-home-container">
        <div class="dsc-section-head compact"><div><span class="dsc-section-kicker">POPULAR SERVICES</span><h2>Start with something<br><em>people request most.</em></h2></div><a class="dsc-outline-link" href="{{ route('public.services.index') }}">View all services <span>→</span></a></div>
        <div class="dsc-service-grid-home">
            @forelse($popularServices->take(6) as $service)
                @include('services.partials.card',['service'=>$service])
            @empty
                <div class="dsc-empty-home">Services will appear here as your catalogue is populated.</div>
            @endforelse
        </div>
    </div>
</section>

<section class="dsc-section dsc-work-preview">
    <div class="dsc-home-container">
        <div class="dsc-work-preview-inner">
            <div><span class="dsc-section-kicker light">OUR WORK</span><h2>Digital products.<br><em>Built to work.</em></h2><p>Explore selected websites, software systems, branding and digital projects developed by Digital Star Consultants.</p><a class="dsc-btn dsc-btn-gold" href="{{ route('work') }}">Explore Our Work <span>↗</span></a></div>
            <div class="dsc-work-art"><div class="work-window"><div class="work-topbar"><i></i><i></i><i></i><span>DSC / PROJECTS</span></div><div class="work-body"><div class="work-side"></div><div class="work-main"><b></b><b></b><div><span></span><span></span><span></span></div></div></div></div></div>
        </div>
    </div>
</section>

<section class="dsc-section dsc-final-cta-home">
    <div class="dsc-home-container dsc-final-inner-home">
        <span class="dsc-section-kicker light">READY TO GET STARTED?</span>
        <h2>Tell us what you<br><em>need to get done.</em></h2>
        <p>Choose a service, send your request, and let our team handle the process with you.</p>
        <div><a class="dsc-btn dsc-btn-gold" href="{{ route('public.services.index') }}">Browse Services <span>→</span></a><a class="dsc-text-link-light" href="{{ route('public.contact.show') }}">Talk to our team ↗</a></div>
    </div>
</section>
@endsection
