@extends('layouts.app')

@section('content')
<section class="works-page">
    <div class="works-hero">
        <div class="works-hero-inner">
            <div class="works-hero-copy">
                <div class="works-eyebrow">OUR WORKS</div>
                <h1>We build solutions<br><em>that drive success.</em></h1>
                <p>Explore a selection of our IT solutions, software projects and creative design work that help businesses grow and stand out.</p>
                <a class="ds-button ds-button-gold" href="#featured-projects">View all projects <span>→</span></a>
            </div>
            <div class="works-hero-stage" data-work-slideshow>
                @foreach($slides as $i => $slide)
                    <article class="work-slide {{ $i === 0 ? 'is-active' : '' }}" data-slide="{{ $i }}" aria-hidden="{{ $i === 0 ? 'false' : 'true' }}">
                        <img src="{{ asset($slide['image']) }}" alt="{{ $slide['title'] }} project preview" loading="{{ $i === 0 ? 'eager' : 'lazy' }}">
                        <div class="work-slide-overlay">
                            <span>{{ $slide['category'] }}</span>
                            <strong>{{ $slide['title'] }}</strong>
                        </div>
                    </article>
                @endforeach
                <button class="work-slide-arrow prev" type="button" aria-label="Previous project" data-slide-prev>←</button>
                <button class="work-slide-arrow next" type="button" aria-label="Next project" data-slide-next>→</button>
                <div class="work-slide-dots" role="tablist" aria-label="Featured projects">
                    @foreach($slides as $i => $slide)
                        <button type="button" class="{{ $i === 0 ? 'is-active' : '' }}" data-slide-dot="{{ $i }}" aria-label="Show {{ $slide['title'] }}" aria-selected="{{ $i === 0 ? 'true' : 'false' }}"></button>
                    @endforeach
                </div>
            </div>
        </div>
    </div>

    <section class="works-featured" id="featured-projects">
        <div class="works-container">
            <div class="works-section-head">
                <div>
                    <div class="works-eyebrow">OUR PORTFOLIO</div>
                    <h2>Featured projects</h2>
                </div>
                <p>IT systems, software and creative work presented in one place.</p>
            </div>

            <div class="works-filter" role="tablist" aria-label="Project categories">
                <button class="is-active" type="button" data-work-filter="all">All projects</button>
                <button type="button" data-work-filter="it">IT &amp; Technology</button>
                <button type="button" data-work-filter="software">Software &amp; Web</button>
                <button type="button" data-work-filter="graphics">Graphics &amp; Branding</button>
            </div>

            <div class="works-project-grid">
                @foreach($projects as $project)
                    <article class="works-project-card" data-project-category="{{ $project['filter'] }}">
                        <button type="button" class="works-project-image works-project-trigger" data-project-id="{{ $loop->index }}" aria-label="Open {{ $project['title'] }} case study">
                            <img src="{{ asset($project['image']) }}" alt="{{ $project['title'] }} preview" loading="lazy">
                            <span class="works-project-tag">{{ $project['category'] }}</span>
                        </button>
                        <div class="works-project-copy">
                            <h3>{{ $project['title'] }}</h3>
                            <p>{{ $project['description'] }}</p>
                            <div class="works-project-meta">
                                @foreach($project['meta'] as $tag)
                                    <span>{{ $tag }}</span>
                                @endforeach
                            </div>
                            <button type="button" class="works-project-link works-project-trigger" data-project-id="{{ $loop->index }}">View case study <span>→</span></button>
                        </div>
                    </article>
                @endforeach
            </div>

            <div class="works-modal" data-work-modal aria-hidden="true">
                <div class="works-modal-backdrop" data-modal-close></div>
                <div class="works-modal-dialog" role="dialog" aria-modal="true" aria-labelledby="works-modal-title">
                    <button type="button" class="works-modal-close" data-modal-close aria-label="Close case study">×</button>
                    <img data-modal-image src="" alt="">
                    <div class="works-modal-content">
                        <div class="works-eyebrow" data-modal-category></div>
                        <h2 id="works-modal-title" data-modal-title></h2>
                        <p data-modal-description></p>
                        <div class="works-project-meta" data-modal-meta></div>
                        <a class="ds-button ds-button-gold" href="{{ route('public.contact.show') }}">Discuss a similar project <span>→</span></a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="works-cta">
        <div class="works-container works-cta-inner">
            <div>
                <div class="works-eyebrow">HAVE A PROJECT IN MIND?</div>
                <h2>Let's build something<br><em>amazing together.</em></h2>
            </div>
            <a href="{{ route('public.contact.show') }}" class="ds-button ds-button-gold">Start your project <span>→</span></a>
        </div>
    </section>

    <section class="works-stats">
        <div class="works-container works-stats-grid">
            @foreach($stats as $stat)
                <div class="works-stat">
                    <strong>{{ $stat['value'] }}</strong>
                    <span>{{ $stat['label'] }}</span>
                </div>
            @endforeach
        </div>
    </section>
</section>
<script>
window.digitalStarProjects = @json($projects);
</script>

@endsection
